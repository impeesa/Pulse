SAMPLE DATA
===========

rake db:seed will create Admin, User, Admin settings, Chart settings.
rake import_sample_results will creates sample results.
rake import_sample_account_details creates sample account details.
rake create_menu_tabs_list creates menu tabs list.
rake import_sample_comments will import sample comments.

rake give_me_everything will drop old database, create new one, run all migrations, import seeds data, import sample data for results, accounts details, menu tabs list, and import sample comments.
