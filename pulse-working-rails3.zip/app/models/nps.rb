class Nps < ActiveRecord::Base
end
