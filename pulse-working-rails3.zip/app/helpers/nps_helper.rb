module NpsHelper
end
