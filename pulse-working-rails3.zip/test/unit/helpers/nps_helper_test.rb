require 'test_helper'

class NpsHelperTest < ActionView::TestCase
end
