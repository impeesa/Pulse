require 'test_helper'

class AuthenticationTest < ActiveSupport::TestCase

end
