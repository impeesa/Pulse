require 'test_helper'

class ResultTest < ActiveSupport::TestCase
end
