# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Pulse::Application.config.secret_token = 'd1a6602b76fbc14dfacacaa3b66027ef261dfeaf7046b147a09c29fcf85e95eebfeae0d7281d219c28ee664c370438031849f6cff34885735e66f21d46dbb826'
