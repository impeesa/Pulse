Sass::Plugin.options[:template_location] = Rails.root.join('app', 'views', 'stylesheets').to_s
Haml::Template.options[:format] = :html5
